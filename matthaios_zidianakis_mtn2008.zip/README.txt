Ο φάκελος περιέχει τα εξής:
    
    -Κώδικα σε μορφή jupyter notebook (.ipynb)
    -Κώδικα σε αρχείο python (.py)
    -Τεχνική αναφορά (.pdf)
    -Τα requirements για τη βιβλιοθήκη που χρησιμοποιήθηκε για τον κώδικα
     (requirements.txt, μπορεί να χρησιμοποιηθεί η εντολή
     pip install -r requirements.txt για να γίνει εγκατάστασή της)
